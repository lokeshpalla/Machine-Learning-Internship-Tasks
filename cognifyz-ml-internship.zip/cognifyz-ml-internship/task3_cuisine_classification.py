import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

print("=== Task 3: Cuisine Classification ===")
df = pd.read_csv("Dataset.csv").dropna()
print("Dataset loaded. Shape:", df.shape)

# Select only numeric columns for features
numeric_cols = df.select_dtypes(include=['number']).columns.tolist()

X = df[numeric_cols]
y = df["Price range"]  # Using Price range as target since Cuisine is non-numeric

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

clf = LogisticRegression(max_iter=1000)
clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))