import pandas as pd
import matplotlib.pyplot as plt

print("=== Task 4: Location Analysis ===")
df = pd.read_csv("Dataset.csv")
print("Dataset loaded. Shape:", df.shape)

plt.scatter(df["Longitude"], df["Latitude"], alpha=0.5)
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.title("Restaurant Distribution")
plt.savefig('restaurant_distribution.png')
print("Location map saved as 'restaurant_distribution.png'")

city_stats = df.groupby("City")["Aggregate rating"].mean()
print("\nTop 5 Cities by Average Rating:")
print(city_stats.sort_values(ascending=False).head(5))