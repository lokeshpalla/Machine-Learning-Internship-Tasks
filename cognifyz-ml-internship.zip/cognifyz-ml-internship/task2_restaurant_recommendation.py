import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
import faiss
import numpy as np

print("=== Task 2: Restaurant Recommendation ===")

df = pd.read_csv("Dataset.csv")
print("Dataset loaded. Shape:", df.shape)
print(df.head())

# Create features from Cuisines and Price range, handling NaN values
df["Cuisines"] = df["Cuisines"].fillna("Unknown")
df["Price range"] = df["Price range"].fillna(0)
df["Features"] = df["Cuisines"].astype(str) + " " + df["Price range"].astype(str)

vectorizer = TfidfVectorizer()
feature_matrix = vectorizer.fit_transform(df["Features"]).astype("float32")
feature_matrix_dense = feature_matrix.toarray()

index = faiss.IndexFlatL2(feature_matrix_dense.shape[1])
index.add(feature_matrix_dense)
print("FAISS index built.")

def recommend(index_id, top_k=5):
    query = feature_matrix_dense[index_id].reshape(1, -1)
    distances, neighbors = index.search(query, top_k+1)
    print(f"\nRecommendations for {df.iloc[index_id]['Restaurant Name']}:")
    for i in neighbors[0][1:]:
        print("-", df.iloc[i]["Restaurant Name"])

recommend(10)