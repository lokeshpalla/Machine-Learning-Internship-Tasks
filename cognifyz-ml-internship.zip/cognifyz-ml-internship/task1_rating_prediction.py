import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

print("=== Task 1: Predict Restaurant Ratings ===")

df = pd.read_csv("Dataset.csv").dropna()
print("Dataset loaded. Shape:", df.shape)
print(df.head())

# Select only numeric columns for features
numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
if "Aggregate rating" in numeric_cols:
    numeric_cols.remove("Aggregate rating")

X = df[numeric_cols]
y = df["Aggregate rating"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
print("Data split into training and testing sets.")

model = SGDRegressor(max_iter=1000, tol=1e-3)
model.fit(X_train, y_train)
print("Model training complete.")

y_pred = model.predict(X_test)
print("MSE:", mean_squared_error(y_test, y_pred))
print("R²:", r2_score(y_test, y_pred))